<?php 
$db = new mysqli("localhost", "root", "","android_amikom");

?>